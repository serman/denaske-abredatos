<?php
// $Id$

/**
 *  Return the js callback()
 */
function _ajax_gmap_js_callback() {
  return 'ajax_gmap.ajaxCallback';
}

/**
 *  Return the library file
 */
function _ajax_gmap_js_library() {
  return 'library/ajax_gmap_library.js';
}